package me.alpha432.oyvey.features.modules.render;

import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.features.setting.Setting;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class WorldModify extends Module {
    public WorldModify() {
        super("CustomSky", "Change fog color", Category.RENDER, true, false, false);
    }

    private Setting<Integer> red2 = register(new Setting("F_Red", 255, 0, 255));
    private Setting<Integer> green2 = register(new Setting("F_Green", 255, 0, 255));
    private Setting<Integer> blue2 = register(new Setting("F_Blue", 255, 0, 255));

    @SubscribeEvent
    public void fogColors(final EntityViewRenderEvent.FogColors event) {
        event.setRed(red2.getValue() / 255f);
        event.setGreen(green2.getValue() / 255f);
        event.setBlue(blue2.getValue() / 255f);

    }

    @SubscribeEvent
    public void fog_density(final EntityViewRenderEvent.FogDensity event) {
        event.setDensity(0.0f);
        event.setCanceled(true);
    }

    int registered = 0;

    @Override
    public void onDisable() {
        MinecraftForge.EVENT_BUS.unregister(this);
        registered = 0;
    }

    @Override
    public void onUpdate() {
        if (registered == 0) {
            MinecraftForge.EVENT_BUS.register(this);
            registered = 1;
        }
    }
}
