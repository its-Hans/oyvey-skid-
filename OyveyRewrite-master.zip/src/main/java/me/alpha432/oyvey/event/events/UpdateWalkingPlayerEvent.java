package me.alpha432.oyvey.event.events;

import me.alpha432.oyvey.event.EventStage;

public class UpdateWalkingPlayerEvent
        extends EventStage {
    public UpdateWalkingPlayerEvent(int stage) {
        super(stage);
    }
}

