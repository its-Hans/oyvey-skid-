package cn.make.module.player;

import cn.make.module.misc.PacketMine;
import cn.make.util.BlockChecker;
import cn.make.util.skid.MathUtil;
import cn.make.util.skid.Timer;
import cn.make.util.skid.two.BlockUtil;
import com.mojang.realmsclient.gui.ChatFormatting;
import me.alpha432.oyvey.event.events.BlockEvent;
import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.features.setting.Setting;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.init.Blocks;
import net.minecraft.init.Enchantments;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;


public class SpeedupMine extends Module {
	private final Setting<Boolean> autoSwitch = register(new Setting("AutoSwitch", false));
	private final Setting<Boolean> silent = register(new Setting("Silent", true));
    private final Setting<Boolean> debug = register(new Setting("Debug", true));
	private final Setting<Double> resetRange = register(new Setting("resetRange", 5.0, 1.0, 6.0));
	public BlockPos renderPos;
	public BlockPos breakPos;
	public EnumFacing breakFace;
	public Timer timer;
	public Timer instaTimer;
	public boolean readyToMine;
	public int oldSlot;
	long start;
	boolean swapBack;

	public SpeedupMine() {
		super("SpeedUpMine", "Mine", Category.PLAYER);
		this.renderPos = null;
		this.breakPos = null;
		this.breakFace = null;
		this.timer = new Timer();
		this.instaTimer = new Timer();
		this.readyToMine = false;
		this.oldSlot = -1;
		this.start = -1L;
	}

	public static int bestSlot(final BlockPos pos) {
		int best = 0;
		double max = 0.0;
		for (int i = 0; i < 9; ++i) {
			final ItemStack stack = SpeedupMine.mc.player.inventory.getStackInSlot(i);
			if (!stack.isEmpty()) {
				float speed = stack.getDestroySpeed(SpeedupMine.mc.world.getBlockState(pos));
				if (speed > 1.0f) {
					final int eff;
					speed += (float) (((eff = EnchantmentHelper.getEnchantmentLevel(Enchantments.EFFICIENCY, stack)) > 0) ? (Math.pow(eff, 2.0) + 1.0) : 0.0);
					if (speed > max) {
						max = speed;
						best = i;
					}
				}
			}
		}
		return best;
	}

	public static boolean canBlockBeBroken(final BlockPos pos) {
		final IBlockState blockState = PacketMine.mc.world.getBlockState(pos);
		final Block block = blockState.getBlock();
		return block.getBlockHardness(blockState, PacketMine.mc.world, pos) != -1.0f;
	}

	public void onEnable() {
		this.breakPos = null;
		this.instaTimer.reset();
		this.timer.reset();
		this.swapBack = false;
	}

	@Override
	public void onTick() {
		if (!nullCheck()) {
			if (this.swapBack) {
				if (this.oldSlot != -1) {
					PacketMine.mc.player.inventory.currentItem = this.oldSlot;
					PacketMine.mc.player.connection.sendPacket(new CPacketHeldItemChange(this.oldSlot));
                    if (debug.getValue()) sendModuleMessage("swapback!");
				}
				this.swapBack = false;
			}
			if (this.breakPos != null) {
				this.oldSlot = PacketMine.mc.player.inventory.currentItem;
				if (PacketMine.mc.player.getDistanceSq(this.breakPos) > MathUtil.square(this.resetRange.getValue().floatValue()) || PacketMine.mc.world.getBlockState(this.breakPos).getBlock() == Blocks.AIR) {
					this.breakPos = null;
					this.breakFace = null;
					this.readyToMine = false;
					return;
				}
				final float breakTime = PacketMine.mc.world.getBlockState(this.breakPos).getBlockHardness(PacketMine.mc.world, this.breakPos) * 40.0f;
				if (this.timer.passedMs((long) breakTime)) {
					this.readyToMine = true;
				}
				if (this.autoSwitch.getValue()) {
					if (this.timer.passedMs((long) breakTime) && bestSlot(this.breakPos) != -1) {
						PacketMine.mc.player.inventory.currentItem = bestSlot(this.breakPos);
						PacketMine.mc.player.connection.sendPacket(new CPacketHeldItemChange(bestSlot(this.breakPos)));
					}
					PacketMine.mc.getConnection().sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, this.breakPos, this.breakFace));
					if (this.oldSlot != -1) {
						PacketMine.mc.player.inventory.currentItem = this.oldSlot;
						PacketMine.mc.player.connection.sendPacket(new CPacketHeldItemChange(this.oldSlot));
					}
				}
			}
		}
	}

	@SubscribeEvent
	public void OnDamageBlock(final BlockEvent event) {
		if (nullCheck()) {
			return;
		}
		if (this.breakPos != null && event.pos.toLong() == this.breakPos.toLong() && this.timer.passedMs((long) (PacketMine.mc.world.getBlockState(this.breakPos).getBlockHardness(PacketMine.mc.world, this.breakPos) * 40.0f)) && bestSlot(event.pos) != -1) {
			if (!this.silent.getValue()) {
				PacketMine.mc.player.inventory.currentItem = bestSlot(this.breakPos);
			}
			PacketMine.mc.player.connection.sendPacket(new CPacketHeldItemChange(bestSlot(this.breakPos)));
			PacketMine.mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, this.breakPos, this.breakFace));
			event.setCanceled(this.swapBack = true);
			sendModuleMessage("send packet " + ChatFormatting.RED + "STOP_DESTROY_BLOCK" + ChatFormatting.RESET + " on pos " + BlockChecker.simpleXYZString(breakPos));
			return;
		}
		if (canBlockBeBroken(event.pos)) {
			if (this.breakPos != null) {
				PacketMine.mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, this.breakPos, this.breakFace));
			}
			this.start = System.currentTimeMillis();
			this.timer.reset();
			this.instaTimer.reset();
			this.breakPos = event.pos;
			this.breakFace = BlockUtil.getRayTraceFacing(breakPos);
			this.readyToMine = false;
			PacketMine.mc.player.swingArm(EnumHand.MAIN_HAND);
			PacketMine.mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, this.breakPos, this.breakFace));
			PacketMine.mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, this.breakPos, this.breakFace));
			if (debug.getValue()) sendModuleMessage("breakblock " + BlockChecker.simpleXYZString(breakPos) + " facing " + breakFace);
			event.setCanceled(true);
		}
	}

	public void onDisable() {
		this.breakPos = null;
	}
}