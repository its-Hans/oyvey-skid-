package cn.make.module.player;

import cn.make.util.BlockCheck2;
import cn.make.util.BlockChecker;
import cn.make.util.getPlayerPos;
import cn.make.util.makeUtil;
import me.alpha432.oyvey.OyVey;
import me.alpha432.oyvey.features.command.Command;
import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.features.setting.Setting;

import cn.make.util.skid.EntityUtil;
import cn.make.util.skid.InventoryUtil;

import net.minecraft.block.BlockAir;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.util.math.BlockPos;

public class PistonTrap extends Module
{
    public final Setting<Double> range;
    public final Setting<Integer> retryTime;
    public final Setting<Boolean> autotoggle;
    public final Setting<Boolean> debug;

    public EntityPlayer target;

    public PistonTrap() {
        super("PistonTrap", "OMG", Category.PLAYER, true, false, false);
        this.range = (Setting<Double>) this.register(new Setting("Range",  4.7,  1.0,  6.0));
        this.retryTime = (Setting<Integer>) this.register(new Setting("ReTryTime",  1,  1,  10));
        this.autotoggle = (Setting<Boolean>) this.register(new Setting("autoToggle",  true));
        this.debug = (Setting<Boolean>) this.register(new Setting("Debug",  false));
    }

    public void onUpdate() {
        //checks
        if (Module.fullNullCheck()) {
            if (autotoggle.getValue()) {
                this.disable();
            } else return;
        }
        if(debug.getValue()) Command.sendMessage("checked");

        if
        (InventoryUtil.getItemHotbar(Item.getItemFromBlock(Blocks.PISTON)) == -1) {
            if(debug.getValue()) Command.sendMessage("NO PISTONS FOUND");
            if (autotoggle.getValue()) {
                this.disable();
            } else return;
        }
        if(debug.getValue())  Command.sendMessage("checked");

        //----------

        //getTarget
        this.target = this.getTarget(this.range.getValue());
        //check target
        if (this.target == null) {
            if(debug.getValue()) Command.sendMessage("no target");
            return;
        }
        if(debug.getValue()) Command.sendMessage("checked");
        //out target
        if(debug.getValue()) Command.sendMessage("target: " + target.toString());
        //tryplace
        this.placeFace(this.target);
        if (autotoggle.getValue()) this.disable();
    }

    public void placeFace(EntityPlayer target) {
        if (debug.getValue()) Command.sendMessage("try pistontrap");

        BlockPos E = getPlayerPos.getFaceEastPos(target);
        if (BlockChecker.getBlockType(E) instanceof BlockAir)
            makeUtil.retryPlace(E, Blocks.PISTON, this.retryTime.getValue(), false);

        BlockPos W = getPlayerPos.getFaceWestPos(target);
        if (BlockChecker.getBlockType(W) instanceof BlockAir)
            makeUtil.retryPlace(W, Blocks.PISTON, this.retryTime.getValue(), false);

        BlockPos N = getPlayerPos.getFaceNorthPos(target);
        if (BlockChecker.getBlockType(N) instanceof BlockAir)
            makeUtil.retryPlace(N, Blocks.PISTON, this.retryTime.getValue(), false);

        BlockPos S = getPlayerPos.getFaceSouthPos(target);
        if (BlockChecker.getBlockType(S) instanceof BlockAir)
            makeUtil.retryPlace(S, Blocks.PISTON, this.retryTime.getValue(), false);

        this.disable();
    }
    private EntityPlayer getTarget(final double range) {
        EntityPlayer target = null;
        double distance = Math.pow(range, 2.0) + 1.0;
        for (final EntityPlayer player : this.mc.world.playerEntities) {
            if (!EntityUtil.isntValid(player, range)) {
                if (OyVey.speedManager.getPlayerSpeed(player) > 10.0) continue;
                if (target != null) if (this.mc.player.getDistanceSq(player) >= distance) continue;
                target = player;
                distance = this.mc.player.getDistanceSq(player);
            }
        }
        return target;
    }
}