package cn.make.module.player;

import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.features.setting.Setting;

import cn.make.util.skid.BlockUtil;
import cn.make.util.skid.InventoryUtil;

import net.minecraft.block.BlockObsidian;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

public class LoverSAnti extends Module
{
    private final Setting<Boolean> rotate;
    private final Setting<Boolean> head;
    private final Setting<Boolean> mine;
    BlockPos pos;
    
    public LoverSAnti() {
        super("LoverSAnti", "Anti piston push.", Category.PLAYER, true, false, false);
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", (Object)true));
        this.head = (Setting<Boolean>)this.register(new Setting("TrapHead", (Object)true));
        this.mine = (Setting<Boolean>)this.register(new Setting("Mine", (Object)false));
    }
    
    public void onUpdate() {
        this.pos = new BlockPos(LoverSAnti.mc.player.posX, LoverSAnti.mc.player.posY, LoverSAnti.mc.player.posZ);
        if (this.getBlock(this.pos.add(0, 1, 1)).getBlock() == Blocks.PISTON || this.getBlock(this.pos.add(0, 2, 1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(0, 1, 2)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(1, 1, 1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(-1, 1, 1)).getBlock() == Blocks.REDSTONE_BLOCK) {
            if (this.getBlock(this.pos.add(0, 1, -1)).getBlock() == Blocks.AIR) {
                this.perform(this.pos.add(0, 1, -1));
            }
            if (this.getBlock(this.pos.add(0, 1, 1)).getBlock() == Blocks.PISTON && this.mine.getValue()) {
                LoverSAnti.mc.playerController.onPlayerDamageBlock(this.pos.add(0, 1, 1), BlockUtil.getRayTraceFacing(this.pos.add(0, 1, 1)));
            }
            if (this.getBlock(this.pos.add(0, 2, 0)).getBlock() == Blocks.AIR && this.head.getValue()) {
                this.perform(this.pos.add(0, 2, -1));
                this.perform(this.pos.add(0, 2, 0));
            }
        }
        if (this.getBlock(this.pos.add(0, 1, -1)).getBlock() == Blocks.PISTON || this.getBlock(this.pos.add(0, 2, -1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(0, 1, -2)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(1, 1, -1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(-1, 1, -1)).getBlock() == Blocks.REDSTONE_BLOCK) {
            if (this.getBlock(this.pos.add(0, 1, 1)).getBlock() == Blocks.AIR) {
                this.perform(this.pos.add(0, 1, 1));
            }
            if (this.getBlock(this.pos.add(0, 1, -1)).getBlock() == Blocks.PISTON && this.mine.getValue()) {
                LoverSAnti.mc.playerController.onPlayerDamageBlock(this.pos.add(0, 1, -1), BlockUtil.getRayTraceFacing(this.pos.add(0, 1, -1)));
            }
            if (this.getBlock(this.pos.add(0, 2, 0)).getBlock() == Blocks.AIR && this.head.getValue()) {
                this.perform(this.pos.add(0, 2, 1));
                this.perform(this.pos.add(0, 2, 0));
            }
        }
        if (this.getBlock(this.pos.add(1, 1, 0)).getBlock() == Blocks.PISTON || this.getBlock(this.pos.add(1, 2, 0)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(2, 1, 0)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(1, 1, 1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(1, 1, -1)).getBlock() == Blocks.REDSTONE_BLOCK) {
            if (this.getBlock(this.pos.add(-1, 1, 0)).getBlock() == Blocks.AIR) {
                this.perform(this.pos.add(-1, 1, 0));
            }
            if (this.getBlock(this.pos.add(1, 1, 0)).getBlock() == Blocks.PISTON && this.mine.getValue()) {
                LoverSAnti.mc.playerController.onPlayerDamageBlock(this.pos.add(1, 1, 0), BlockUtil.getRayTraceFacing(this.pos.add(1, 1, 0)));
            }
            if (this.getBlock(this.pos.add(0, 2, 0)).getBlock() == Blocks.AIR && this.head.getValue()) {
                this.perform(this.pos.add(-1, 2, 0));
                this.perform(this.pos.add(0, 2, 0));
            }
        }
        if (this.getBlock(this.pos.add(-1, 1, 0)).getBlock() == Blocks.PISTON || this.getBlock(this.pos.add(-1, 2, 0)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(-2, 1, 0)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(-1, 1, 1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(-1, 1, -1)).getBlock() == Blocks.REDSTONE_BLOCK) {
            if (this.getBlock(this.pos.add(1, 1, 0)).getBlock() == Blocks.AIR) {
                this.perform(this.pos.add(1, 1, 0));
            }
            if (this.getBlock(this.pos.add(-1, 1, 0)).getBlock() == Blocks.PISTON && this.mine.getValue()) {
                LoverSAnti.mc.playerController.onPlayerDamageBlock(this.pos.add(-1, 1, 0), BlockUtil.getRayTraceFacing(this.pos.add(-1, 1, 0)));
            }
            if (this.getBlock(this.pos.add(0, 2, 0)).getBlock() == Blocks.AIR && this.head.getValue()) {
                this.perform(this.pos.add(1, 2, 0));
                this.perform(this.pos.add(0, 2, 0));
            }
        }
        if (this.getBlock(this.pos.add(0, 1, 1)).getBlock() == Blocks.STICKY_PISTON || this.getBlock(this.pos.add(0, 2, 1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(0, 1, 2)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(1, 1, 1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(-1, 1, 1)).getBlock() == Blocks.REDSTONE_BLOCK) {
            if (this.getBlock(this.pos.add(0, 1, -1)).getBlock() == Blocks.AIR) {
                this.perform(this.pos.add(0, 1, -1));
            }
            if (this.getBlock(this.pos.add(0, 1, 1)).getBlock() == Blocks.STICKY_PISTON && this.mine.getValue()) {
                LoverSAnti.mc.playerController.onPlayerDamageBlock(this.pos.add(0, 1, 1), BlockUtil.getRayTraceFacing(this.pos.add(0, 1, 1)));
            }
            if (this.getBlock(this.pos.add(0, 2, 0)).getBlock() == Blocks.AIR && this.head.getValue()) {
                this.perform(this.pos.add(0, 2, -1));
                this.perform(this.pos.add(0, 2, 0));
            }
        }
        if (this.getBlock(this.pos.add(0, 1, -1)).getBlock() == Blocks.STICKY_PISTON || this.getBlock(this.pos.add(0, 2, -1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(0, 1, -2)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(1, 1, -1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(-1, 1, -1)).getBlock() == Blocks.REDSTONE_BLOCK) {
            if (this.getBlock(this.pos.add(0, 1, 1)).getBlock() == Blocks.AIR) {
                this.perform(this.pos.add(0, 1, 1));
            }
            if (this.getBlock(this.pos.add(0, 1, -1)).getBlock() == Blocks.STICKY_PISTON && this.mine.getValue()) {
                LoverSAnti.mc.playerController.onPlayerDamageBlock(this.pos.add(0, 1, -1), BlockUtil.getRayTraceFacing(this.pos.add(0, 1, -1)));
            }
            if (this.getBlock(this.pos.add(0, 2, 0)).getBlock() == Blocks.AIR && this.head.getValue()) {
                this.perform(this.pos.add(0, 2, 1));
                this.perform(this.pos.add(0, 2, 0));
            }
        }
        if (this.getBlock(this.pos.add(1, 1, 0)).getBlock() == Blocks.STICKY_PISTON || this.getBlock(this.pos.add(1, 2, 0)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(2, 1, 0)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(1, 1, 1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(1, 1, -1)).getBlock() == Blocks.REDSTONE_BLOCK) {
            if (this.getBlock(this.pos.add(-1, 1, 0)).getBlock() == Blocks.AIR) {
                this.perform(this.pos.add(-1, 1, 0));
            }
            if (this.getBlock(this.pos.add(1, 1, 0)).getBlock() == Blocks.STICKY_PISTON && this.mine.getValue()) {
                LoverSAnti.mc.playerController.onPlayerDamageBlock(this.pos.add(1, 1, 0), BlockUtil.getRayTraceFacing(this.pos.add(1, 1, 0)));
            }
            if (this.getBlock(this.pos.add(0, 2, 0)).getBlock() == Blocks.AIR && this.head.getValue()) {
                this.perform(this.pos.add(-1, 2, 0));
                this.perform(this.pos.add(0, 2, 0));
            }
        }
        if (this.getBlock(this.pos.add(-1, 1, 0)).getBlock() == Blocks.STICKY_PISTON || this.getBlock(this.pos.add(-1, 2, 0)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(-2, 1, 0)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(-1, 1, 1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(-1, 1, -1)).getBlock() == Blocks.REDSTONE_BLOCK) {
            if (this.getBlock(this.pos.add(1, 1, 0)).getBlock() == Blocks.AIR) {
                this.perform(this.pos.add(1, 1, 0));
            }
            if (this.getBlock(this.pos.add(-1, 1, 0)).getBlock() == Blocks.STICKY_PISTON && this.mine.getValue()) {
                LoverSAnti.mc.playerController.onPlayerDamageBlock(this.pos.add(-1, 1, 0), BlockUtil.getRayTraceFacing(this.pos.add(-1, 1, 0)));
            }
            if (this.getBlock(this.pos.add(0, 2, 0)).getBlock() == Blocks.AIR && this.head.getValue()) {
                this.perform(this.pos.add(1, 2, 0));
                this.perform(this.pos.add(0, 2, 0));
            }
        }
    }
    
    private IBlockState getBlock(final BlockPos block) {
        return LoverSAnti.mc.world.getBlockState(block);
    }
    
    public String getDisplayInfo() {
        if (LoverSAnti.mc.player != null) {
            if (this.getBlock(this.pos.add(-1, 1, 0)).getBlock() == Blocks.PISTON || this.getBlock(this.pos.add(-1, 2, 0)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(-2, 1, 0)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(-1, 1, 1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(-1, 1, -1)).getBlock() == Blocks.REDSTONE_BLOCK) {
                return "Working";
            }
            if (this.getBlock(this.pos.add(1, 1, 0)).getBlock() == Blocks.PISTON || this.getBlock(this.pos.add(1, 2, 0)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(2, 1, 0)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(1, 1, 1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(1, 1, -1)).getBlock() == Blocks.REDSTONE_BLOCK) {
                return "Working";
            }
            if (this.getBlock(this.pos.add(0, 1, -1)).getBlock() == Blocks.PISTON || this.getBlock(this.pos.add(0, 2, -1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(0, 1, -2)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(1, 1, -1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(-1, 1, -1)).getBlock() == Blocks.REDSTONE_BLOCK) {
                return "Working";
            }
            if (this.getBlock(this.pos.add(0, 1, 1)).getBlock() == Blocks.PISTON || this.getBlock(this.pos.add(0, 2, 1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(0, 1, 2)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(1, 1, 1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(-1, 1, 1)).getBlock() == Blocks.REDSTONE_BLOCK) {
                return "Working";
            }
            if (this.getBlock(this.pos.add(-1, 1, 0)).getBlock() == Blocks.STICKY_PISTON || this.getBlock(this.pos.add(-1, 2, 0)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(-2, 1, 0)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(-1, 1, 1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(-1, 1, -1)).getBlock() == Blocks.REDSTONE_BLOCK) {
                return "Working";
            }
            if (this.getBlock(this.pos.add(1, 1, 0)).getBlock() == Blocks.STICKY_PISTON || this.getBlock(this.pos.add(1, 2, 0)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(2, 1, 0)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(1, 1, 1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(1, 1, -1)).getBlock() == Blocks.REDSTONE_BLOCK) {
                return "Working";
            }
            if (this.getBlock(this.pos.add(0, 1, -1)).getBlock() == Blocks.STICKY_PISTON || this.getBlock(this.pos.add(0, 2, -1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(0, 1, -2)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(1, 1, -1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(-1, 1, -1)).getBlock() == Blocks.REDSTONE_BLOCK) {
                return "Working";
            }
            if (this.getBlock(this.pos.add(0, 1, 1)).getBlock() == Blocks.STICKY_PISTON || this.getBlock(this.pos.add(0, 2, 1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(0, 1, 2)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(1, 1, 1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(-1, 1, 1)).getBlock() == Blocks.REDSTONE_BLOCK) {
                return "Working";
            }
        }
        return null;
    }
    
    private void perform(final BlockPos pos2) {
        final int old = LoverSAnti.mc.player.inventory.currentItem;
        if (LoverSAnti.mc.world.getBlockState(pos2).getBlock() == Blocks.AIR) {
            if (InventoryUtil.findHotbarBlock(BlockObsidian.class) != -1) {
                LoverSAnti.mc.player.inventory.currentItem = InventoryUtil.findHotbarBlock(BlockObsidian.class);
                LoverSAnti.mc.playerController.updateController();
                BlockUtil.placeBlock(pos2, EnumHand.MAIN_HAND, this.rotate.getValue(), true, false);
                LoverSAnti.mc.player.inventory.currentItem = old;
                LoverSAnti.mc.playerController.updateController();
            }
        }
    }
}
