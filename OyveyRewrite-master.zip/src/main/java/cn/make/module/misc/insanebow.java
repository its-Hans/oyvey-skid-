package cn.make.module.misc;

import me.alpha432.oyvey.event.events.PacketEvent;
import me.alpha432.oyvey.features.command.Command;
import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.features.setting.Setting;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.*;
import net.minecraft.util.EnumHand;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class insanebow extends Module {
    public static insanebow instance;
    private final Setting<Integer> fastbow = register(new Setting<>("fastbow", 3, 0, 20, "autorelease, if 0 dont do"));
    private final Setting<Integer> bowbomb = register(new Setting<>("bowbomb", 0, 0, 100, "32kbow, if 0 dont do"));
    private final Setting<Boolean> bowspeed = register(new Setting("bowspeed", false, "message something, something bug"));
    private final Setting<Boolean> quiver = register(new Setting("quiver", true, "shoot arrow at sky"));

    private final Setting<String> disableOldVelocity = register(new Setting<String>("disableOldVelocity","!velocity enabled false", v -> bowspeed.getValue()));
    private final Setting<String> enableNewVelocity = register(new Setting<String>("enableNewVelocity","@set velocity enabled true", v -> bowspeed.getValue()));
    private final Setting<String> enableBlink = register(new Setting<String>("enableBlink","@set blink enabled true", v -> bowspeed.getValue()));
    private final Setting<String> enableTimer = register(new Setting<String>("enableTimer","@set timer enabled true", v -> bowspeed.getValue()));

    private final Setting<String> enableOldVelocity = register(new Setting<String>("enableOldVelocity","!velocity enabled true", v -> bowspeed.getValue()));
    private final Setting<String> disableNewVelocity = register(new Setting<String>("disableNewVelocity","@set velocity enabled false", v -> bowspeed.getValue()));
    private final Setting<String> disableBlink = register(new Setting<String>("disableBlink","@set blink enabled false", v -> bowspeed.getValue()));
    private final Setting<String> disableTimer = register(new Setting<String>("disableTimer","@set timer enabled false", v -> bowspeed.getValue()));

    public insanebow() {
        super("insaneBow", "holy", Category.MISC, true, false, false);
        instance = this;
    }
    @Override
    public void onEnable() {
        if (bowspeed.getValue()) moduleBowSpeedDisable();
    }
    @Override
    public void onDisable() {
        if (bowspeed.getValue()) moduleBowSpeedDisable();
    }

    @Override
    public void onUpdate() {
        if (fullNullCheck()) return;
        if (
            mc.player.inventory.getCurrentItem().getItem() instanceof ItemBow
                && mc.player.isHandActive()
                && mc.player.getItemInUseMaxCount() >= fastbow.getValue()
        ) {
            if (quiver.getValue()) mc.player.connection.sendPacket(new CPacketPlayer.Rotation(mc.player.cameraYaw, -90f, mc.player.onGround));
            if (fastbow.getValue() != 0) mc.playerController.onStoppedUsingItem(mc.player);
            Command.sendMessage("shoot bow");
            if (bowspeed.getValue()) moduleBowSpeedEnable();
        }
    }
    public void moduleBowSpeedEnable() {
        insanebow.mc.player.connection.sendPacket(new CPacketChatMessage(disableOldVelocity.getValue()));
        insanebow.mc.player.connection.sendPacket(new CPacketChatMessage(enableNewVelocity.getValue()));
        insanebow.mc.player.connection.sendPacket(new CPacketChatMessage(enableBlink.getValue()));
        insanebow.mc.player.connection.sendPacket(new CPacketChatMessage(enableTimer.getValue()));
        Command.sendMessage("enable bowspeed modules");
    }
    public void moduleBowSpeedDisable() {
        insanebow.mc.player.connection.sendPacket(new CPacketChatMessage(enableOldVelocity.getValue()));
        insanebow.mc.player.connection.sendPacket(new CPacketChatMessage(disableNewVelocity.getValue()));
        insanebow.mc.player.connection.sendPacket(new CPacketChatMessage(disableBlink.getValue()));
        insanebow.mc.player.connection.sendPacket(new CPacketChatMessage(disableTimer.getValue()));
    }

    public static boolean onlyground = true;

    @SubscribeEvent
    public void onPacketSend(PacketEvent.Send event) {
        if (bowbomb.getValue() == 0) return;
        if (event.getStage() != 0) return;

        if (event.getPacket() instanceof CPacketPlayerDigging) {
            CPacketPlayerDigging packet = event.getPacket();

            if (packet.getAction() == CPacketPlayerDigging.Action.RELEASE_USE_ITEM) {
                ItemStack handStack = mc.player.getHeldItem(EnumHand.MAIN_HAND);
                if (!handStack.isEmpty() &&handStack.getItem() instanceof ItemBow) doSpoofs();
            }

        } else if (event.getPacket() instanceof CPacketPlayerTryUseItem) event.getPacket();
    }

    private void doSpoofs() {
        if (onlyground & !mc.player.onGround) return;
        mc.player.connection.sendPacket(new CPacketEntityAction(mc.player, CPacketEntityAction.Action.START_SPRINTING));
        for (int index = 0; index < bowbomb.getValue(); ++index) {
            mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY - 1e-10, mc.player.posZ, true));
            mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1e-10, mc.player.posZ, false));
        }
    }
}
