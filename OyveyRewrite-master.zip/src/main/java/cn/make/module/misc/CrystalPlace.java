package cn.make.module.misc;

import cn.make.util.makeUtil;
import cn.make.util.skid.RebirthUtil;
import cn.make.util.skid.two.BlockUtil;
import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.features.setting.Setting;
import net.minecraft.init.Items;
import net.minecraft.network.play.client.*;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

import java.util.regex.Pattern;

public class CrystalPlace extends Module {
    private Setting<String> posX = this.register(new Setting<>("X", "0"));
    private Setting<String> posY = this.register(new Setting<>("Y", "0"));
    private Setting<String> posZ = this.register(new Setting<>("Z", "0"));
    private Setting<Switch> switchMode = this.register(new Setting<>("SwitchMode", Switch.Silent));
    private Setting<Place> placeMode = this.register(new Setting<>("PlaceMode", Place.A, "maybe only A do rotate"));

    public CrystalPlace() {
        super("CrystalPlace", "Place", Category.MISC);
    }

    @Override
    public void onEnable() {
        int x = getStringInt(posX.getValue());
        int y = getStringInt(posY.getValue());
        int z = getStringInt(posZ.getValue());
        if (
            x == 0
            || y == 0
            || z == 0
        ) return;

        int crystal = makeUtil.getItemHotbar(Items.END_CRYSTAL);
        int oldslot = CrystalPlace.mc.player.inventory.currentItem;
        if (crystal == -1 | oldslot == -1) return;

        BlockPos pos = new BlockPos(x,y,z);
        if (switchMode.getValue() == Switch.Silent) switchTo(crystal);
        if (switchMode.getValue() == Switch.onlySwitchTo) switchTo(crystal);

        if (placeMode.getValue() == Place.A) placeModeA(pos);
        if (placeMode.getValue() == Place.B) placeModeB(pos);
        if (placeMode.getValue() == Place.C) placeModeC(pos);

        if (switchMode.getValue() == Switch.Silent) switchTo(oldslot);
    }
    public void switchTo(int slot) {
        if (slot == -1) return;
        makeUtil.mc.player.connection.sendPacket(new CPacketHeldItemChange(slot));
        makeUtil.mc.player.inventory.currentItem = slot;
        makeUtil.mc.playerController.updateController();
    }

    public void placeModeA(BlockPos pos) {
        RebirthUtil.placeCrystal(pos, true, true);
    }

    public void placeModeB(BlockPos pos) {
        makeUtil.placeCrystalOnBase(pos);
    }

    public void placeModeC(BlockPos pos) {
        BlockUtil.mc.player.connection.sendPacket(new CPacketPlayerTryUseItemOnBlock(pos, EnumFacing.UP, EnumHand.MAIN_HAND, (float)pos.getX(), (float)pos.getY(), (float)pos.getZ()));
    }

    enum Switch {Silent,onlySwitchTo,noSwitch}
    enum Place {A,B, C}

    public static Integer getStringInt(String string) {
        Pattern pattern = Pattern.compile("^[-\\+]?[\\d]*$");
        if (pattern.matcher(string).matches()) return Integer.parseInt(string);
        else return 0;
    }
}