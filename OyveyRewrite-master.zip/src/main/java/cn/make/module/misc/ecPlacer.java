package cn.make.module.misc;

import cn.make.util.BlockChecker;
import cn.make.util.getPlayerPos;
import cn.make.util.makeUtil;
import me.alpha432.oyvey.features.command.Command;
import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.features.setting.Setting;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;

public class ecPlacer
extends Module {
    public final Setting<Boolean> debug = this.register(new Setting<>("debug", false));

    static BlockPos feetPos = null;
    static BlockPos facePos = null;
    static BlockPos bestPos = null;
    static List<BlockPos> posLists = new ArrayList<BlockPos>();
    static List<BlockPos> canPlaceList = new ArrayList<BlockPos>();

    @Override
    public void onEnable() {
        feetPos = getPlayerPos.getBurrowPos(ecPlacer.mc.player);
        facePos = getPlayerPos.getFacePos(ecPlacer.mc.player);
        posLists.addAll(BlockChecker.getNSWE(feetPos));
        posLists.addAll(BlockChecker.getNSWE(facePos));

        for (BlockPos pos : posLists) if (BlockChecker.canPlace(pos)) canPlaceList.add(pos);

        if (!canPlaceList.isEmpty()) {
            bestPos = BlockChecker.bestDist(canPlaceList);
            if (debug.getValue()) Command.sendMessage("found pos" + bestPos);
        } else {
            if (debug.getValue()) Command.sendMessage("no pos found to place");
            this.disable();
        }
    }

    public ecPlacer() {
        super("EnderChest", "Auto Obby", Category.MISC, true, false, false);
    }
    @Override
    public void onUpdate() {
        if (bestPos == null) return;
        if (this.mc.world.getBlockState(bestPos).getBlock() == Blocks.AIR) {
            if (debug.getValue()) Command.sendMessage("trying place at" + bestPos);
            makeUtil.retryPlace(bestPos, Blocks.ENDER_CHEST, 2, false);
        }
    }

}

