package cn.make;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.alpha432.oyvey.OyVey;
import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.features.setting.Setting;
import me.alpha432.oyvey.util.TextUtil;
import org.lwjgl.opengl.Display;

import java.util.Objects;

public class tweaksClient extends Module {
	static tweaksClient INSTANCE;
	public Setting<String> clientName = register(new Setting("ClientName", clientname));
	public Setting<String> cmLeft = register(new Setting("cmLeft", MessageLeft));
	public Setting<String> cmRight = register(new Setting("cmRight", MessageRight));
	public Setting<ColorList> brColor = register(new Setting("BracketColor", ColorList.WHITE));
	public Setting<ColorList> cmColor = register(new Setting("MessageColor", ColorList.AQUA));
	public Setting<String> clientPrefix = register(new Setting("ClientPrefix", defaultPrefix));
	public Setting<String> clientTitle = register(new Setting("ClientTitle", title));
	public Setting<AutoSave> autoSave = register(new Setting("AutoSaving", AutoSave.NO));
	public tweaksClient() {
		super("clientSetting", "set", Category.CLIENT);
		INSTANCE = this;
	}
	public static final String clientid = "oyvey";
	public static final String clientname = "OyVey";
	public static final String MessageLeft = " ";
	public static final String MessageRight = "$";
	public static final String clientversion = "0.0.3";
	public static final String simplecfgpath = "OyVey";
	public static final String defaultPrefix = "-";
	public static final String title = ("uwu this " + clientname + " " + clientversion); //if set "no" will cancel load title

	@Override
	public void onEnable() {
		setClient();
		this.disable();
	}
	@Override
	public void onLoad() {
		setClient();
	}
	public static tweaksClient getInstance() {
		if (INSTANCE == null) INSTANCE = new tweaksClient();
		return INSTANCE;
	}

	//dont edit
	public static final String configpath = (simplecfgpath + "/");
	static String clientMessageLeft() {
		return toColor(getInstance().brColor.getValue()) + getInstance().cmLeft.getValue() + TextUtil.RESET;
	}
	static String clientMessageRight() {
		return  toColor(getInstance().brColor.getValue()) + getInstance().cmRight.getValue() + TextUtil.RESET;
	}
	static String clentMessage() {
		return toColor(getInstance().cmColor.getValue()) + getInstance().clientName.getValue() + TextUtil.RESET;
	}

	public static boolean setClient() {
		boolean name = setClientName();
		boolean prefix = setClientPrefix();
		boolean title = setTitle();
		return name && prefix && title;
	}

	public static boolean setTitle() {
		if (!isManagersLoaded()) return false;
		String ti = getInstance().clientTitle.getValue();
		String getti = Display.getTitle();
		if (!Objects.equals(getti, ti)) setTitle(ti);
		return Objects.equals(getti, ti);
	}
	public static boolean setClientName() {
		if (!isManagersLoaded()) return false;
		String cm = getCustomClientMessage();
		String getcm = OyVey.commandManager.getClientMessage();
		if (!Objects.equals(getcm, cm)) OyVey.commandManager.setClientMessage(cm);
		return Objects.equals(getcm, cm);
	}
	public static boolean setClientPrefix() {
		if (!isManagersLoaded()) return false;
		String cp = tweaksClient.getInstance().clientPrefix.getValue();
		String getcp = OyVey.commandManager.getPrefix();
		if (!Objects.equals(getcp, cp)) OyVey.commandManager.setPrefix(cp);
		return Objects.equals(getcp, cp);
	}

	public static boolean isManagersLoaded() {
		if (OyVey.moduleManager == null || OyVey.commandManager == null) {
			OyVey.LOGGER.warn("cannot link managers");
			return false;
		} else return true;
	}

	static void setTitle(String titleName) {
		if (!Objects.equals(titleName, "no")) {
			Display.setTitle(titleName);
		}
	}

	static String getCustomClientMessage() {
		return (clientMessageLeft() + clentMessage() + clientMessageRight());
	}
	public enum AutoSave{
		DisableClickGUI,
		NO
	}
	public enum ColorList {
		BLACK,
		DARK_BLUE,
		DARK_GREEN,
		DARK_AQUA,
		DARK_RED,
		DARK_PURPLE,
		GOLD,
		GRAY,
		DARK_GRAY,
		BLUE,
		GREEN,
		AQUA,
		RED,
		LIGHT_PURPLE,
		YELLOW,
		WHITE
	}
	static ChatFormatting toColor(ColorList color) {
		if (color == ColorList.BLACK) return ChatFormatting.BLACK;
		if (color == ColorList.DARK_BLUE) return ChatFormatting.DARK_BLUE;
		if (color == ColorList.DARK_GREEN) return ChatFormatting.DARK_GREEN;
		if (color == ColorList.DARK_AQUA) return ChatFormatting.DARK_AQUA;
		if (color == ColorList.DARK_RED) return ChatFormatting.DARK_RED;
		if (color == ColorList.DARK_PURPLE) return ChatFormatting.DARK_PURPLE;
		if (color == ColorList.GOLD) return ChatFormatting.GOLD;
		if (color == ColorList.GRAY) return ChatFormatting.GRAY;
		if (color == ColorList.DARK_GRAY) return ChatFormatting.DARK_GRAY;
		if (color == ColorList.BLUE) return ChatFormatting.BLUE;
		if (color == ColorList.GREEN) return ChatFormatting.GREEN;
		if (color == ColorList.AQUA) return ChatFormatting.AQUA;
		if (color == ColorList.RED) return ChatFormatting.RED;
		if (color == ColorList.LIGHT_PURPLE) return ChatFormatting.LIGHT_PURPLE;
		if (color == ColorList.YELLOW) return ChatFormatting.YELLOW;
		if (color == ColorList.WHITE) return ChatFormatting.WHITE;

		return ChatFormatting.RESET;
	}
	public static TextUtil.Color toTextUtilColor(ColorList color) {
		if (color == ColorList.BLACK) return TextUtil.Color.BLACK;
		if (color == ColorList.DARK_BLUE) return TextUtil.Color.DARK_BLUE;
		if (color == ColorList.DARK_GREEN) return TextUtil.Color.DARK_GREEN;
		if (color == ColorList.DARK_AQUA) return TextUtil.Color.DARK_AQUA;
		if (color == ColorList.DARK_RED) return TextUtil.Color.DARK_RED;
		if (color == ColorList.DARK_PURPLE) return TextUtil.Color.DARK_PURPLE;
		if (color == ColorList.GOLD) return TextUtil.Color.GOLD;
		if (color == ColorList.GRAY) return TextUtil.Color.GRAY;
		if (color == ColorList.DARK_GRAY) return TextUtil.Color.DARK_GRAY;
		if (color == ColorList.BLUE) return TextUtil.Color.BLUE;
		if (color == ColorList.GREEN) return TextUtil.Color.GREEN;
		if (color == ColorList.AQUA) return TextUtil.Color.AQUA;
		if (color == ColorList.RED) return TextUtil.Color.RED;
		if (color == ColorList.LIGHT_PURPLE) return TextUtil.Color.LIGHT_PURPLE;
		if (color == ColorList.YELLOW) return TextUtil.Color.YELLOW;
		if (color == ColorList.WHITE) return TextUtil.Color.WHITE;

		return TextUtil.Color.NONE;
	}
}
