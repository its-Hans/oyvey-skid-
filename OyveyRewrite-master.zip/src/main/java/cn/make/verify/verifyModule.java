package cn.make.verify;

import me.alpha432.oyvey.features.command.Command;
import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.features.setting.Setting;

public class verifyModule extends Module
{
    public verifyModule() {
        super("verify", "rwar", Category.MISC, true, false, false);
    }
	private Setting<Mode> mode = this.register(new Setting("Mode", Mode.outHWID));

	@Override
	public void onEnable()
	{
		if (this.mode.getValue() == Mode.Crash) {
			GodMode.crashOnYou();
		}
		if (this.mode.getValue() == Mode.outHWID) {
			if (GodMode.hwidCheck()) Command.sendMessage("true");
			if (!GodMode.hwidCheck()) Command.sendMessage("false");
			Command.sendMessage(GodMode.GensHWID());
		}
		this.disable();
	}
	private enum Mode {Crash, outHWID}
}