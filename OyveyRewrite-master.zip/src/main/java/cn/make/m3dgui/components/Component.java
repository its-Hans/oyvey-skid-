package cn.make.m3dgui.components;

import cn.make.m3dgui.components.items.Item;
import cn.make.m3dgui.components.items.buttons.Button;
import cn.make.m3dgui.modules.clickGuiModule;
import cn.make.util.skid.RenderUtil;
import me.alpha432.oyvey.OyVey;
import me.alpha432.oyvey.features.Feature;
import cn.make.m3dgui.M3dC3tGui;
import me.alpha432.oyvey.util.ColorUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.ISound;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.SoundEvent;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.ArrayList;

public class Component
        extends Feature {
    public static int[] counter1 = new int[]{1};
    private final Minecraft minecraft = Minecraft.getMinecraft();
    private final ArrayList<Item> items = new ArrayList();
    private final int barHeight;
    public boolean drag;
    private int old;
    private int x;
    private int y;
    private int x2;
    private int y2;
    private int width;
    private int height;
    private boolean open;
    private int angle;
    private boolean hidden = false;
    private int startcolor;

    public Component(String name, int x, int y, boolean open) {
        super(name);
        this.x = x;
        this.y = y;
        this.width = 88 + clickGuiModule.getInstance().moduleWidth.getValue();
        this.height = 18;
        this.barHeight = 15;
        this.angle = 180;
        this.open = open;
        this.setupItems();
    }

    public static void drawModalRect(int var0, int var1, float var2, float var3, int var4, int var5, int var6, int var7, float var8, float var9) {
        Gui.drawScaledCustomSizeModalRect((int)var0, (int)var1, (float)var2, (float)var3, (int)var4, (int)var5, (int)var6, (int)var7, (float)var8, (float)var9);
    }

    public static void glColor(Color color) {
        GL11.glColor4f((float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)((float)color.getAlpha() / 255.0f));
    }

    public static float calculateRotation(float var0) {
        float f = 0;
        var0 %= 360.0f;
        if (f >= 180.0f) {
            var0 -= 360.0f;
        }
        if (var0 < -180.0f) {
            var0 += 360.0f;
        }
        return var0;
    }

    public void setupItems() {
    }

    private void drag(int mouseX, int mouseY) {
        if (!this.drag) {
            return;
        }
        this.x = this.x2 + mouseX;
        this.y = this.y2 + mouseY;
    }

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.old = this.x;
        if (this.getName() == "Combat")
            this.old = this.old + clickGuiModule.getInstance().moduleDistance.getValue() * 1;
        if (this.getName() == "Misc")
            this.old = this.old + clickGuiModule.getInstance().moduleDistance.getValue() * 2;
        if (this.getName() == "Render")
            this.old = this.old + clickGuiModule.getInstance().moduleDistance.getValue() * 3;
        if (this.getName() == "Movement")
            this.old = this.old + clickGuiModule.getInstance().moduleDistance.getValue() * 4;
        if (this.getName() == "Player")
            this.old = this.old + clickGuiModule.getInstance().moduleDistance.getValue() * 5;
        if (this.getName() == "Client")
            this.old = this.old + clickGuiModule.getInstance().moduleDistance.getValue() * 6;
        this.width = 88 + clickGuiModule.getInstance().moduleWidth.getValue();
        int endcolor;
        this.drag(mouseX, mouseY);
        counter1 = new int[]{1};
        float totalItemHeight = this.open ? this.getTotalItemHeight() - 2.0f : 0.0f;
        float f = totalItemHeight;
        if (clickGuiModule.getInstance().rainbowg.getValue().booleanValue()) {
            if (clickGuiModule.getInstance().rainbowModeHud.getValue() == clickGuiModule.rainbowMode.Static) {
                this.startcolor = ColorUtil.rainbow(clickGuiModule.getInstance().rainbowHue.getValue()).getRGB();
                endcolor = ColorUtil.rainbow(clickGuiModule.getInstance().rainbowHue.getValue()).getRGB();
            }
        } else {
            this.startcolor = ColorUtil.toRGBA(clickGuiModule.getInstance().g_red.getValue(), clickGuiModule.getInstance().g_green.getValue(), clickGuiModule.getInstance().g_blue.getValue(), clickGuiModule.getInstance().g_alpha.getValue());
        }
        endcolor = ColorUtil.toRGBA(clickGuiModule.getInstance().g_red1.getValue(), clickGuiModule.getInstance().g_green1.getValue(), clickGuiModule.getInstance().g_blue1.getValue(), clickGuiModule.getInstance().g_alpha1.getValue());
        RenderUtil.drawRect(this.old, this.y, this.old + this.width, this.y + this.height - 5, ColorUtil.toRGBA(clickGuiModule.getInstance().red.getValue(), clickGuiModule.getInstance().green.getValue(), clickGuiModule.getInstance().blue.getValue(), 255));
        RenderUtil.drawGradientSideways(this.old - 1, this.y, this.old + this.width + 1, (float)(this.y + this.barHeight) - 2.0f, this.startcolor, endcolor);
        if (this.open) {
            RenderUtil.drawGradientSideways(this.old - 1, (float)this.y + 13.2f, this.old + this.width + 1, (float)this.y + totalItemHeight + 19.0f, this.startcolor, endcolor);
            RenderUtil.drawRect(this.old, (float)this.y + 13.2f, this.old + this.width, (float)(this.y + this.height) + totalItemHeight, ColorUtil.toRGBA(0, 0, 0, clickGuiModule.getInstance().alphaBox.getValue()));
        }
        OyVey.textManager.drawStringWithShadow(this.getName(), (float) this.old + 3, (float) this.y - 4.0f - (float) M3dC3tGui.getClickGui().getTextOffset(), -1);

        if (!this.open) {
            if (this.angle > 0) {
                this.angle -= 6;
            }
        } else if (this.angle < 180) {
            this.angle += 6;
        }
        if (this.open) {
            RenderUtil.drawRect(this.old, (float)this.y + 12.5f, this.old + this.width, (float)(this.y + this.height) + totalItemHeight, 0x77000000);
            if (clickGuiModule.getInstance().outline.getValue().booleanValue()) {
                GlStateManager.disableTexture2D();
                GlStateManager.enableBlend();
                GlStateManager.disableAlpha();
                GlStateManager.tryBlendFuncSeparate((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
                GlStateManager.shadeModel((int)7425);
                GL11.glBegin((int)2);
                GL11.glColor4f((float)((float) clickGuiModule.getInstance().red.getValue().intValue() / 255.0f), (float)((float) clickGuiModule.getInstance().green.getValue().intValue() / 255.0f), (float)((float) clickGuiModule.getInstance().blue.getValue().intValue() / 255.0f), (float)255.0f);
                GL11.glVertex3f((float)this.old, (float)((float)this.y - 0.5f), (float)0.0f);
                GL11.glVertex3f((float)(this.old + this.width), (float)((float)this.y - 0.5f), (float)0.0f);
                GL11.glVertex3f((float)(this.old + this.width), (float)((float)(this.y + this.height) + totalItemHeight), (float)0.0f);
                GL11.glVertex3f((float)this.old, (float)((float)(this.y + this.height) + totalItemHeight), (float)0.0f);
                GL11.glEnd();
                GlStateManager.shadeModel((int)7424);
                GlStateManager.disableBlend();
                GlStateManager.enableAlpha();
                GlStateManager.enableTexture2D();
            }
        }
        if (this.open) {
            float y = (float)(this.getY() + this.getHeight()) - 3.0f;
            for (Item item : this.getItems()) {
                Component.counter1[0] = counter1[0] + 1;
                if (item.isHidden()) continue;
                item.setLocation((float)this.old + 2.0f, y);
                item.setWidth(this.getWidth() - 4);
                item.drawScreen(mouseX, mouseY, partialTicks);
                y += (float)item.getHeight() + 1.5f;
            }
        }
    }

    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (mouseButton == 0 && this.isHovering(mouseX, mouseY)) {
            this.x2 = this.old - mouseX;
            this.y2 = this.y - mouseY;
            M3dC3tGui.getClickGui().getComponents().forEach(component -> {
                if (component.drag) {
                    component.drag = false;
                }
            });
            this.drag = true;
            return;
        }
        if (mouseButton == 1 && this.isHovering(mouseX, mouseY)) {
            this.open = !this.open;
            mc.getSoundHandler().playSound((ISound)PositionedSoundRecord.getMasterRecord((SoundEvent)SoundEvents.UI_BUTTON_CLICK, (float)1.0f));
            return;
        }
        if (!this.open) {
            return;
        }
        this.getItems().forEach(item -> item.mouseClicked(mouseX, mouseY, mouseButton));
    }

    public void mouseReleased(int mouseX, int mouseY, int releaseButton) {
        if (releaseButton == 0) {
            this.drag = false;
        }
        if (!this.open) {
            return;
        }
        this.getItems().forEach(item -> item.mouseReleased(mouseX, mouseY, releaseButton));
    }

    public void onKeyTyped(char typedChar, int keyCode) {
        if (!this.open) {
            return;
        }
        this.getItems().forEach(item -> item.onKeyTyped(typedChar, keyCode));
    }

    public void addButton(Button button) {
        this.items.add(button);
    }

    public int getX() {
        return this.old;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return this.y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getWidth() {
        return this.width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return this.height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public boolean isHidden() {
        return this.hidden;
    }

    public void setHidden(boolean hidden) {
        this.hidden = hidden;
    }

    public boolean isOpen() {
        return this.open;
    }

    public final ArrayList<Item> getItems() {
        return this.items;
    }

    private boolean isHovering(int mouseX, int mouseY) {
        return mouseX >= this.getX() && mouseX <= this.getX() + this.getWidth() && mouseY >= this.getY() && mouseY <= this.getY() + this.getHeight() - (this.open ? 2 : 0);
    }

    private float getTotalItemHeight() {
        float height = 0.0f;
        for (Item item : this.getItems()) {
            height += (float)item.getHeight() + 1.5f;
        }
        return height;
    }
}

